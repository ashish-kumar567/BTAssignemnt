package StepDefinition;

import static org.junit.Assert.assertTrue;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BTStepDefinitions {

	WebDriver driver;
	WebDriverWait wait ;
	
	@Given("I launch the BT application URL")
	public void i_launch_the_BT_application_URL() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\amard\\Downloads\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		wait= new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.get("https://www.bt.com/");
	}
	
	 @When("Accept cookie pop-up if it appears")
	    public void acceptCookoeIfAppear() {
		 
	        try {
	        wait= new WebDriverWait(driver, Duration.ofSeconds(10));
        	
	        driver.switchTo().frame(0);
	        driver.getWindowHandles();
        	WebElement acceptCookie = wait.until(
                    ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(), 'Accept all cookies')]")));
        	acceptCookie.click();
	        } catch (Exception e) {
            // Cookie banner not found, proceed
	        }
	    }
	 
	 @When("I hover to the Mobile menu")
	    public void i_hover_over_the_mobile_menu(){
		 wait= new WebDriverWait(driver, Duration.ofSeconds(10));
     	       
	        WebElement mobileMenu = driver.findElement(By.xpath("(//span[.='Mobile'])[1]"));
	        Actions builder = new Actions(driver);
	        builder.moveToElement(mobileMenu).perform();
	      
	    }
	 
	 @When("I select Mobile phones from the Mobile menu")
	    public void iSelectMobilePhonesFromTheMobileMenu() {
	        WebElement mobilePhonesOption = driver.findElement(By.xpath("(//span[.='Mobile phones'])[1]"));
	        mobilePhonesOption.click();
	    }

	    @Then("I should see at least 3 banners below {string}")
	    public void iShouldSeeAtLeastBannersBelow(String sectionTitle) {
	        WebElement section = driver.findElement(By.xpath("//a[.='See handset deals']"));
	        String title=section.getText();
	        System.out.println(title);
	        List<WebElement> banners = section.findElements(By.cssSelector("flexpay_flexpaycard_container__GnRx9"));
	        assertTrue(banners.size() >= 3);
	    }

	    @When("I scroll down and click {string}")
	    public void iScrollDownAndClick(String linkText) {
	        WebElement link = driver.findElement(By.linkText(linkText));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", link);
	        link.click();
	    }

	    @Then("I should validate the title of the new page")
	    public void iShouldValidateTheTitleOfTheNewPage() {
	        String expectedTitle = "GET SET FOR";
	        String actualTitle = driver.getTitle();
	        assertTrue(actualTitle.contains(expectedTitle));
	    }

	    @Then("I should validate the presence of the specific text")
	    public void iShouldValidateThePresenceOfTheSpecificText() {
	        WebElement textElement = driver.findElement(By.xpath("//*[contains(text(), 'Massive £312 saving + double data was 125GB250GBEssential Plan was £27£14Per month*')]"));
	        assertTrue(textElement.isDisplayed());
	    }
	  @And("I close the browser")
	    public void i_close_the_browser() {
	        if (driver != null) {
	            driver.quit();
	        }
	    }
}
