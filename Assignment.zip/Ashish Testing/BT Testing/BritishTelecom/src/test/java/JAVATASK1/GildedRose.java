package JAVATASK1;

public class GildedRose {
    public static void updateQuality(Item[] items) {
        for (Item item : items) {
            switch (item.name) {
                case "Sulfuras":
                    // Sulfuras does not change
                    break;

                case "Aged Brie":
                    // Aged Brie increases in Quality
                    increaseQuality(item);
                    break;

                case "Backstage passes":
                    // Backstage passes increase in Quality differently as the SellIn date approaches
                    increaseBackstagePassQuality(item);
                    break;

                case "Conjured":
                    // Conjured items degrade in Quality twice as fast
                    decreaseConjuredQuality(item);
                    break;

                default:
                    // Normal items degrade in Quality normally
                    decreaseNormalQuality(item);
                    break;
            }
            
            // Update SellIn value
            item.sellIn--;
            
            // If SellIn is negative, degrade Quality more quickly
            if (item.sellIn < 0) {
                if ("Backstage passes".equals(item.name)) {
                    item.quality = 0; // Backstage passes drop to 0 after the concert
                } else if (!"Sulfuras".equals(item.name)) {
                    if ("Conjured".equals(item.name)) {
                        decreaseConjuredQuality(item);
                    } else {
                        decreaseNormalQuality(item);
                    }
                }
            }
        }
    }

    private static void increaseQuality(Item item) {
        if (item.quality < 50) {
            item.quality++;
        }
    }

    private static void increaseBackstagePassQuality(Item item) {
        if (item.quality < 50) {
            item.quality++;
            if (item.sellIn < 10) {
                if (item.quality < 50) {
                    item.quality++;
                }
            }
            if (item.sellIn < 5) {
                if (item.quality < 50) {
                    item.quality++;
                }
            }
        }
    }

    private static void decreaseNormalQuality(Item item) {
        if (item.quality > 0) {
            item.quality--;
        }
    }

    private static void decreaseConjuredQuality(Item item) {
        if (item.quality > 0) {
            item.quality -= 2;
            if (item.quality < 0) {
                item.quality = 0;
            }
        }
    }
      
    public static void main(String[] args) {
        Item[] items = new Item[] {
            new Item("Aged Brie", 10, 20),
            new Item("Backstage passes", 15, 20),
            new Item("Sulfuras", 0, 80),
            new Item("Conjured Mana Cake", 3, 6),
            new Item("Normal Item", 5, 10)
        };

        System.out.println("Initial State:");
        printItems(items);

        for (int day = 0; day < 20; day++) {
            GildedRose.updateQuality(items);
            System.out.println("\nDay " + (day + 1) + ":");
            printItems(items);
        }
    }

    private static void printItems(Item[] items) {
        for (Item item : items) {
            System.out.println(item.name + ", " + item.sellIn + ", " + item.quality);
        }
    }
}
