package Runner;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="D:\\Ashish Testing\\BT Testing\\BritishTelecom\\src\\test\\java\\Features"
		,glue={"StepDefinition"}
		)
public class TestRunner {

}
